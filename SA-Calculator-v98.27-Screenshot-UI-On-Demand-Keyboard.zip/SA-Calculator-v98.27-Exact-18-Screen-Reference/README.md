# SA Calculator v98.27 — Currency + Unit Converter Reference UI

- App version: `1.98.27-v98.27`
- Android versionCode: `1098027`
- Design target: supplied 18-screen Android reference — midnight navy background, bright-blue primary actions, dark rounded inputs, green result panels, compact per-tool toolbar, four-tab bottom navigation and rounded calculator keypad.
- Destinations: Calculator, Currency Converter, Unit Converter, Discount, Percent, Sales Tax, Body Metrics, Date, Fuel Cost, Fuel Efficiency, Grade Average, Number Base, Loan/EMI, Savings, Tip, Unit Price, World Time and Settings. Favorites remains a separate bottom-navigation destination.
- Currency Converter uses stacked full-width flag/code/name selectors and amount/result fields, central swap, rate status, explicit Convert action and the existing precision-safe exchange-rate engine.
- Unit Converter opens at Length → Meter (m) to Kilometer (km), with full-width stacked category/source/value/target/result controls and explicit Convert action.
- Discount and Percent use full-width reference-style fields, green result surfaces and explicit Calculate actions; both percentage modes remain available.
- Existing calculation IDs and handlers, currency refresh logic, loan schedule, tip presets, unit-price comparison, world-time zones, date reminders, favorites, settings, history and scientific functions are retained.
- Responsive finishing: narrow phones, short landscape screens, safe-area insets, bounded scrolling, keyboard resize metadata, visible focus and reduced-motion support.
- Cache identity: `sa-calculator-v98-27-converter-reference-layout`.

## GitHub upload

1. Extract this ZIP and upload the **contents** of the extracted project folder to the repository root (so `package.json` is at repository root), or upload this complete ZIP to repository root.
2. Replace `.github/workflows/main.yml` with `main-v98.27-currency-unit-reference.yml` supplied alongside the ZIP. The ZIP also contains the exact workflow under `.github/workflows/main.yml`.
3. Commit and run `SA Calculator v98.27 - All 18 Tools Reference UI Android APK`.
4. Download artifact `SA-Calculator-Debug-APK-1.98.27-v98.27`.
5. Install it and verify Settings → About & Support reports `v1.98.27-v98.27`.

## Local checks

```sh
npm test
npm run build:web
```

GitHub Actions performs the Android SDK/Gradle APK build and APK identity/checksum verification. Local tests and web-bundle success do not prove the remote APK build or physical-device rendering. Install the APK and complete screenshot/touch QA before treating the release as fully verified.

## v98.27 screenshot-led UI refresh
The supplied 18-screen visual is the active design direction. Tool screens now open without an on-screen keypad; tapping an editable numeric field opens the shared keypad. The basic calculator retains its permanently visible keypad. See `UI-REFRESH-KEYBOARD-POLISH-v98.27.md` for scope and verification boundaries.
