# SA Calculator v98.14 — All-screen UI design specification

## Design direction
A premium, calm, high-contrast calculator workspace: deep navy brand chrome, restrained cyan/blue accents, warm gold only for high-value emphasis, light/dark theme compatibility, clear numeric hierarchy, and predictable spacing. The visual pass is CSS-only; it does not change calculator formulas, currency-rate calculations, tool field order, or screen routing.

## Shared design rules
- 8pt-derived spacing rhythm; responsive 13–22px content gutters and 9–16px section gaps.
- 18–22px card corners; 14–15px controls; 50px standard input/select height and 42px minimum button hit area.
- Tabular numerals for amounts/results; labels stay secondary; primary results use accent surfaces and stronger weight.
- Inputs receive a visible focus ring; reduced-motion, high-contrast and forced-colors modes are retained.
- Compact phone (≤360px), short landscape, and tablet (≥600px) layouts have dedicated rules.
- Drawers, dialogs, currency picker, history, scientific panel and dock keypads share the same elevation and touch language.

## Screen-by-screen design
1. **Calculator** — deep navy result/display surface, cyan preview value, distinct DEG/power/delete/memory utility strip, tactile 4-column keypad, blue gradient equals key.
2. **Currencies** — two equally legible editable amount panels, obvious swap affordance, readable currency selector, clear rate freshness/status card and refresh action.
3. **Units** — consistent source/destination cards, clear unit selectors, strong converted-result hierarchy.
4. **Discount** — vertically separated input/reference rows, aligned amount fields, persistent numeric dock.
5. **Percent** — segmented mode tabs, consistent input cards and a highlighted result panel for each mode.
6. **Sales tax** — compact tax mode/rate inputs and a visually distinct total result.
7. **Body metrics** — balanced responsive metric fields, legible BMI/BMR outputs and status panel.
8. **Date** — calm empty state, readable event list, high-visibility add action and elevated event dialog.
9. **Fuel cost** — grouped distance/efficiency/fuel-price inputs and a prominent total-cost result.
10. **Fuel efficiency** — aligned before/after/fuel/distance inputs; consumed-fuel and efficiency outputs use clear hierarchy.
11. **Grade average** — clear course-list rows, compact header, prominent GPA summary and floating add-course action.
12. **Number base** — four distinct base rows with aligned labels and tabular values; dedicated keypad remains usable on narrow screens.
13. **Loan / EMI** — grouped loan inputs, monthly/interest/total result hierarchy and horizontally scrollable amortization table.
14. **Savings** — grouped contribution/frequency/term/rate/tax fields and highlighted maturity balance.
15. **Tip** — bill/people/tip/tax controls; per-person amount emphasized, warm gold result treatment used sparingly.
16. **Unit price** — comparison rows visually separate item, price, quantity and unit price; best deal gets a restrained highlight.
17. **World time** — dark hero clock for the base time, searchable zone controls and consistent city clock cards.
18. **Settings** — grouped preference cards, readable descriptions, consistent row heights, accessible switches/selects and separated destructive actions.

## Brand and app shell
- Existing SA metallic-silver / electric-blue / gold artwork remains the single brand source for app header, PWA icons and Android launcher resources.
- App header uses navy-to-blue brand chrome with 42px icon controls and consistent brand mark sizing.
- System overlays and pickers use matching rounded surfaces and safe-area padding.

## Verification performed
- Existing automated suite plus all-screen coverage test: **159 passed, 0 failed, 0 skipped**.
- JavaScript syntax check passed.
- Android web bundle regenerated and source/www copies compared identical.
- ZIP archive integrity checked after packaging.

## Device QA still required
A browser/device screenshot session could not be completed in this environment. Test the installed APK on physical Android at 320/360/390/430 CSS px widths, portrait and landscape, light/dark themes, large text, RTL, gesture navigation and three-button navigation. Also verify status-bar contrast, notch insets, keyboard overlap, splash and launcher icon on-device. No claim of a physically verified or bug-free APK is made until those checks are run.
