# SA Calculator v98.6 — Micro-level bug-fix report

## Confirmed defect reproduced

**Android service-worker packaging omission**

- Runtime registration in `assets/js/app.js` requests `./service-worker.js`.
- The previous `scripts/prepare-android-web.mjs` staged `index.html`, `manifest.webmanifest` and `assets/`, but omitted the service worker.
- Therefore the generated Capacitor web root did not contain the worker at the registered path. The service-worker registration could fail in the Android bundle, preventing the intended worker cache/update behavior.

## Fix applied

- Added `service-worker.js` to the required source asset checks.
- Added `service-worker.js` to the Android web staging copy list.
- Added an executable regression test that runs the staging script, verifies the output worker exists, parses its precache list, and verifies every precache target exists in `www/`.
- Bumped app/package/manifest/cache identity to `1.98.6-v98.6`.

## Regression verification

- Full Node test suite: **150 passed, 0 failed**.
- Android web bundle preparation: passed.
- Generated `www/service-worker.js`: present.
- All service-worker precache assets in generated `www/`: present.
- JavaScript syntax and server/security/calculator/currency/tool regression coverage: passed as part of the full suite.

## Scope and limitations

No calculator arithmetic, Power, scientific notation, memory, currency conversion, settings, localization or UI algorithms were changed because the supplied automated suite did not reproduce a defect in those areas. This is deliberate: changing stable calculation behavior without a reproduced failure risks introducing regressions.

This ZIP is source/build-prepared, not a signed APK. A physical Android System WebView test, APK installation, offline/online transition test, and low-end-device performance test remain necessary. Therefore this report does not claim universal zero bugs or device certification.
