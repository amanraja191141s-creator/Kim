'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}
function parser(degrees = false) {
  const context = {
    STATE: { isDegMode: degrees, implicitMult: true },
    normalizeStandaloneScientificEntry: value => value,
    normalizeScientificExpressionGlyphs: value => value,
    Math, Number, String, Set, Error
  };
  vm.runInNewContext(`${extract('evaluateArithmetic')};${extract('getCalculatorRepeatOperation')};globalThis.calc=evaluateArithmetic;globalThis.repeat=getCalculatorRepeatOperation;`, context);
  return context;
}
const near = (actual, expected, epsilon = 1e-10) => assert.ok(Math.abs(actual - expected) <= epsilon, `${actual} != ${expected}`);

test('basic calculator arithmetic, precedence, unary signs and parentheses', () => {
  const c = parser();
  near(c.calc('2+3*4'), 14);
  near(c.calc('(2+3)*4'), 20);
  near(c.calc('-2^2'), -4);
  near(c.calc('(-2)^2'), 4);
  near(c.calc('2^-2'), 0.25);
  near(c.calc('2^3^2'), 512);
  near(c.calc('1--2'), 3);
  near(c.calc('1+-2'), -1);
  near(c.calc('2(3+4)'), 14);
  near(c.calc('(2)(3)'), 6);
  near(c.calc('(2+3)4'), 20);
});

test('calculator percent policy is contextual and does not leak through chained operations', () => {
  const c = parser();
  near(c.calc('200+10%'), 220);
  near(c.calc('200-10%'), 180);
  near(c.calc('200*10%'), 20);
  near(c.calc('200/10%'), 2000);
  near(c.calc('50%'), 0.5);
  near(c.calc('200+10%+10%'), 242);
  near(c.calc('200+(10%)'), 220);
  near(c.calc('200+-10%'), 180);
});

test('constants, implicit multiplication, scientific notation and scientific functions', () => {
  const c = parser();
  near(c.calc('2pi'), 2 * Math.PI);
  near(c.calc('pi2'), 2 * Math.PI);
  near(c.calc('2pi2'), 4 * Math.PI);
  near(c.calc('e2'), 100);
  near(c.calc('e+2'), 100);
  near(c.calc('e-2'), 0.01);
  near(c.calc('2e2'), 200);
  assert.throws(() => c.calc('e'), /Expected number|Function requires parentheses/);
  assert.throws(() => c.calc('2e'));
  assert.throws(() => c.calc('e^2'));
  near(c.calc('e20'), 1e20, 1e6);
  near(c.calc('e+20'), 1e20, 1e6);
  near(c.calc('e-20'), 1e-20, 1e-30);
  near(c.calc('2e20'), 2e20, 1e6);
  near(c.calc('2e3'), 2000);
  assert.throws(() => c.calc('pi2', false));
  assert.throws(() => c.calc('2pi', false));
  near(c.calc('2e3'), 2000);
  near(c.calc('1e-7'), 1e-7, 1e-20);
  near(c.calc('2sin(30)'), 2 * Math.sin(30));
  near(c.calc('sqrt(81)'), 9);
  near(c.calc('√9'), 3);
  near(c.calc('∛(-8)'), -2);
  near(c.calc('5!'), 120);
  near(c.calc('0!'), 1);
});


test('e is an exponent-entry marker only: bare e is invalid and e20 is 1×10^20', () => {
  const c = parser();
  assert.throws(() => c.calc('e'));
  assert.throws(() => c.calc('e^2'));
  assert.throws(() => c.calc('2e'));
  near(c.calc('e20'), 1e20, 1e6);
  near(c.calc('e+20'), 1e20, 1e6);
  near(c.calc('e-20'), 1e-20, 1e-30);
  near(c.calc('2e20'), 2e20, 1e6);
  near(c.calc('1e20'), 1e20, 1e6);
});

test('degree/radian modes and domain/range errors are handled safely', () => {
  const deg = parser(true);
  near(deg.calc('sin(30)'), 0.5);
  near(deg.calc('cos(60)'), 0.5);
  near(deg.calc('tan(45)'), 1);
  near(deg.calc('asin(1)'), 90);
  const rad = parser(false);
  near(rad.calc('sin(pi/2)'), 1);
  assert.throws(() => rad.calc('sqrt(-1)'));
  assert.throws(() => rad.calc('ln(0)'));
  assert.throws(() => rad.calc('1/0'));
  assert.throws(() => rad.calc('171!'));
  assert.throws(() => rad.calc('(-1)^0.5'));
});

test('malformed adjacent numeric literals are rejected instead of becoming implicit multiplication', () => {
  const c = parser();
  for (const expression of ['1..2', '1.2.3', '1e2.3', '.5.6', '12..', '1.2.3+4']) {
    assert.throws(() => c.calc(expression), undefined, expression);
  }
  near(c.calc('1.2*3'), 3.6);
  near(c.calc('.5+1'), 1.5);
});

test('repeat-equals extraction ignores scientific exponent signs', () => {
  const c = parser();
  assert.equal(c.repeat('1e-3'), null);
  assert.equal(c.repeat('1e+3'), null);
  assert.deepEqual(JSON.parse(JSON.stringify(c.repeat('2+3'))), { operator: '+', rhs: '3' });
  assert.deepEqual(JSON.parse(JSON.stringify(c.repeat('2e-3+1'))), { operator: '+', rhs: '1' });
  assert.deepEqual(JSON.parse(JSON.stringify(c.repeat('5*-2'))), { operator: '*', rhs: '-2' });
});

test('memory recall resets transient result, repeat and scientific continuation state', () => {
  const recall = source.slice(source.indexOf("if (action === 'MR') {"), source.indexOf("const current = currentCalculatorNumericValue();", source.indexOf("if (action === 'MR') {")));
  assert.match(recall, /STATE\.calcScientificContinuation = isScientificRecall[\s\S]*?\? \{ displayToken: recalledDisplay, exactValue: recalledValue \}[\s\S]*?: null/);
  assert.match(recall, /STATE\.calcScientificErrorPreview = false/);
  assert.match(recall, /STATE\.calcRawValue = recalledValue/);
  assert.match(recall, /STATE\.calcRepeat = null/);
  assert.match(recall, /STATE\.isResultMode = false/);
});

test('strong vibration preference maps to the visible 50ms heavy setting', () => {
  const context = { STATE: { keySound: false, hapticEnabled: true, vibeStrength: 'heavy' }, navigator: { vibrate: value => { context.lastVibration = value; return true; } } };
  vm.runInNewContext(`${extract('triggerHaptic')};globalThis.run=triggerHaptic;`, context);
  context.run();
  assert.equal(context.lastVibration, 50);
  context.STATE.vibeStrength = 'medium'; context.run();
  assert.equal(context.lastVibration, 30);
  context.STATE.vibeStrength = 'light'; context.run();
  assert.equal(context.lastVibration, 15);
  context.STATE.vibeStrength = 'strong'; context.run();
  assert.equal(context.lastVibration, 50);
  assert.match(source, /\['light', 'medium', 'heavy'\]\.includes\(s\.vibeStrength\)/);
});


test('calculator keeps all 12-digit integers ordinary and switches at 13 digits', () => {
  const context = {
    STATE: { precision: 'auto', trailingZeros: false, thousandsSep: 'none' },
    Number, Math, String
  };
  context.formatResultNumber = value => String(Number(value));
  vm.runInNewContext(`${extract('toSuperscriptExponent')};${extract('formatScientificEntryDisplay')};${extract('calculatorIntegerDigitCount')};${extract('calculatorNeedsScientificNotation')};${extract('formatCalculatorResultNumber')};globalThis.fmt=formatCalculatorResultNumber;`, context);
  assert.equal(context.fmt(99999999999), '99999999999');
  assert.equal(context.fmt(100000000000), '100000000000');
  assert.equal(context.fmt(999999999999), '999999999999');
  assert.equal(context.fmt(1e12), '1×10¹²');
});

test('committed scientific display token stays scientific when continuing with arithmetic operators', () => {
  const state = {
    calcVal: '1×10⁹',
    calcRawValue: 1000000000,
    calcResultExpression: 'e9',
    calcExpr: 'e9',
    calcScientificContinuation: null
  };
  const context = {
    STATE: state, Number, String,
    toSuperscriptExponent: value => String(value).replace(/-/g, '⁻'),
    normalizeStandaloneScientificEntry: value => value,
    normalizeScientificExpressionGlyphs: value => value.replace(/([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+))\\s*×\\s*10([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)/g, (_, m, e) => `${m}e${e.split('').map(ch => ({'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁺':'+','⁻':'-'}[ch] ?? ch)).join('')}`)
  };
  vm.runInNewContext(`${extract('calculatorExpressionFromCommittedResult')};${extract('normalizedCalcExpression')};globalThis.continueResult=calculatorExpressionFromCommittedResult;globalThis.normalize=normalizedCalcExpression;`, context);
  const token = context.continueResult();
  assert.equal(token, '1×10⁹');
  assert.equal(state.calcScientificContinuation.displayToken, '1×10⁹');
  for (const operator of ['+', '−', '×', '÷']) {
    const expression = `${token}${operator}2`;
    assert.equal(context.normalize(expression), `1000000000${operator === '−' ? '-' : operator === '×' ? '*' : operator === '÷' ? '/' : '+'}2`);
  }
  assert.equal(state.calcScientificContinuation.displayToken, '1×10⁹');
});
