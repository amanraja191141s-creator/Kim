# SA Calculator v98.27 — Build Verification

## Source identity
- Package: `sa-calculator`
- Version: `1.98.27-v98.27`
- Android versionCode: `1098027`
- Service-worker cache: `sa-calculator-v98-27-converter-reference-layout`

## Checks completed in the source workspace
- JavaScript syntax: `node --check assets/js/app.js` passed.
- Regression suite: **202 tests passed, 0 failed** (`npm test`).
- Android web bundle: `npm run build:web` passed; 10 required assets verified, including the service worker.
- Generated `www` bundle contains the current v98.27 HTML, JavaScript and CSS.
- GitHub Actions workflow parsed successfully as YAML.
- `.github/workflows/main.yml`, root `android-apk.yml`, and standalone `main-v98.27-currency-unit-reference.yml` are identical.
- Archive integrity: checked with `unzip -t` before delivery.

## Not yet verified
- Android Gradle `assembleDebug` was not run in this local workspace; the supplied GitHub Actions workflow performs SDK setup, Capacitor project generation/sync, native branding, Gradle build, APK identity verification and artifact upload.
- No physical Android device screenshot/touch test was available in this workspace. Visual fit, status/navigation-bar insets, currency-picker interaction and every tool's touch behavior must be confirmed on the installed APK.

Automated source tests and a successful web bundle are not proof of a completed Android APK or pixel-perfect device rendering.
